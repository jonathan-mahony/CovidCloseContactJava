package Model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactDAOTest {

	@Test
	void testDelete() {
	
		Contact c = new Contact();
		
		fail("Not yet implemented");
	}

}
